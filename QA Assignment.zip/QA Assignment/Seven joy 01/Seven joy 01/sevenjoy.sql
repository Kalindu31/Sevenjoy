-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2024 at 10:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sevenjoy`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `ad_no` int(10) NOT NULL,
  `month` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`ad_no`, `month`) VALUES
(1, 'March'),
(3, 'May');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ad_no` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `birthday` date NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ad_no`, `name`, `birthday`, `address`, `contact`) VALUES
(1, 'B.Kalindu Harshana Rathnabharathi', '2001-01-12', '57,Egodauyana,Moratuwa', 776033898),
(2, 'B.A.C.D.B.Walage', '2001-01-03', '65,dampe,piliyandala', 778456589),
(3, 'harsha', '2005-03-02', '57,Egodauyana,Moratuwa', 778456589);

-- --------------------------------------------------------

--
-- Table structure for table `uniform`
--

CREATE TABLE `uniform` (
  `itemcode` varchar(20) NOT NULL,
  `item` varchar(20) NOT NULL,
  `size` varchar(5) NOT NULL,
  `amount` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uniform`
--

INSERT INTO `uniform` (`itemcode`, `item`, `size`, `amount`) VALUES
('sh1', 'shorts', 'XS', 20),
('sh2', 'shorts', 'S', 20),
('sh3', 'shorts', 'M', 20),
('sh4', 'shorts', 'L', 20),
('sh5', 'shorts', 'XL', 15),
('sk1', 'skirt', 'XS', 20),
('sk2', 'skirt', 'S', 20),
('sk3', 'skirt', 'M', 20),
('sk4', 'skirt', 'L', 20),
('sk5', 'skirt', 'XL', 20),
('ts1', 'tshirt', 'XS', 25),
('ts2', 'tshirt', 'S', 20),
('ts3', 'tshirt', 'M', 20),
('ts4', 'tshirt', 'L', 20),
('ts5', 'tshirt', 'XL', 20);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`ad_no`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ad_no`);

--
-- Indexes for table `uniform`
--
ALTER TABLE `uniform`
  ADD PRIMARY KEY (`itemcode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
