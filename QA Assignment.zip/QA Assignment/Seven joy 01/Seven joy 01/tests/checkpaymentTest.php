<?php

require 'checkpayment.php'; // Ensure this path is correct relative to removedTest.php

use PHPUnit\Framework\TestCase;

class checkpaymentTest extends TestCase
{
    public function testcheckpaymentFunction() {
        // Pass an argument to removedFunction
        $result = checkpaymentFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = checkpaymentFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>
