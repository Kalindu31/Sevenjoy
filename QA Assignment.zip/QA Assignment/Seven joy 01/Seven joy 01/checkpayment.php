<?php
function checkpaymentFunction($param) {
    return $param === 'expected_value' ? 'expected output' : 'unexpected output';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="style1.css">
    <title>Seven Joy PreSchool</title>
    <link rel="icon" href="./photos/Seven Joy Logo.png" type="image/png">
</head>

<body>

    <div class="header">
        <div class="headertext">
        <div class="school-name">Seven Joy Pre School</div>

        </div>
</div>
    
    <div class="nav">
        <a href="home.php">Home</a>
        <a href="payment.php">New Payment</a>
        
    </div>
    
    
    <div class="title-container">
    <h2 class="title">Check Payment</h2>
</div>
    

<form action="#" method="GET">
      <label for="ad_no">Admission number:</label>
      <input type="text" id="ad_no" name="ad_no" required>
    
      <input type="submit" value="Submit"></div></div>
    

      <?php
       ini_set('display_errors', 'off');

include 'dbconnection.php';

 
$id = $_GET['ad_no'];


if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
else{
	//connection confirmed

  
	$sql = "SELECT * FROM student where ad_no=$id";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
        echo "<br><br><strong>Student Admission Number :</strong> ". $row["ad_no"]. "<br>";

        echo "<br><strong>Student Name :</strong> ". $row["name"]. "<br>";
    }
}


	
	$sql = "SELECT * FROM payment where ad_no=$id";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br><strong>Last Paid Month :</strong> ". $row["month"]. "<br>";
    }
} else {
    echo "Order Status:";
}

	$conn->close();
}


?>


</body>
</html>
