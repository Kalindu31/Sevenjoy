<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="style1.css">
    <title>Seven Joy PreSchool</title>
    <link rel="icon" href="./photos/Seven Joy Logo.png" type="image/png">
</head>

<body>

    <div class="header">
        <div class="headertext">
        <div class="school-name">Seven Joy Pre School</div>

        </div>
</div>
    
    <div class="nav">
        <a href="home.php">Home</a>
        <a href="uniforms.php">Uniforms</a>
    </div>
    
    
    <div class="title-container">
    <h2 class="title">Update Uniforms</h2>
</div>
    
<form action="" method="GET">
            <label for="item">Select Item:</label>
            <select name="item" id="item">
            <option value="">Select item</option>
                <option value="tshirt">tshirt</option>
                <option value="shorts">shorts</option>
                <option value="skirt">skirt</option>
            
            </select>
            <label for="size" ><br>Select Size:</label>
            <select name="size" id="size">
                <option value="">Select Size</option>
                <option value="XS">XS</option>
                <option value="S">S</option>
                <option value="M">M</option>
                <option value="L">L</option>
                <option value="XL">XL</option>
                
            </select>
            <input type="submit" value="Check Availability">
           
            <?php
       ini_set('display_errors', 'off');
include 'dbconnection.php';
$item=$_GET["item"];
$size=$_GET["size"];
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
else{
	//connection confirmed
	echo "";
	$sql = "SELECT * FROM uniform where item='$item' and size='$size'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br><br><strong>Item count in store:</strong> ". $row["amount"]. "<br>";
    }
} else {
    echo "";
}


$conn->close();
	
}


?>
</form>
<form method= "post" action="">
      <label for="count">Uniforms intake count</label>
      <input type="text" id="count" name="count" required>

     
        <input type="submit" value="Confirm">
            

      <?php
       //ini_set('display_errors', 'off');
            include 'dbconnection.php';
            $count=$_POST["count"];
            $brand=$_GET["item"];
            $size=$_GET["size"];


        
            
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            else{
                
        
            $sql = "UPDATE uniform SET amount = amount +$count WHERE item='$item' and size='$size'";

            if ($conn->query($sql) === TRUE) {
                echo 'Go back to home';
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            //connection closed.
            $conn->close();
            }
        
            ?>

</body>
</html>
