<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="style1.css">
    <title>Seven Joy PreSchool</title>
    <link rel="icon" href="./photos/Seven Joy Logo.png" type="image/png">
</head>

<body>

    <div class="header">
        <div class="headertext">
        <div class="school-name">Seven Joy Pre School</div>

        </div>
</div>
    
    <div class="nav">
        <a href="home.php">Home</a>
        <a href="tdetails.php">Teacher Details</a>
        
    </div>
    
    <div class="title-container">
    <h2 class="title">Teacher Addmision</h2>
</div>
    

      
    <form action="#" method="GET">
      <label for="ad_no">Teacher's number:</label>
      <input type="text" id="ad_no" name="ad_no" required>
      <label for="t_name">Teacher Name:</label>
      <input type="text" id="t_name" name="t_name" required>
      <label for="date">Birthday:</label>
      <input type="date" id="date" name="date" required>
      <label for="address">Address:</label>
      <input type="text" id="address" name="address" required>
      <label for="contact">Contact no:</label>
      <input type="text" id="contact" name="contact" required>
      

      
      <input type="submit" value="Submit"></div></div>
    
      <?php
ini_set('display_errors', 'off');

include 'dbconnection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $adno = $_GET['ad_no'];
    $name = $_GET['t_name'];
    $date = $_GET['date'];
    $address = $_GET['address'];
    $contact = $_GET['contact'];


    // Prepare and bind the SQL statement for student insertion
    $stmt_student = $conn->prepare("INSERT INTO teacher (ad_no, name, birthday, address, contact) VALUES (?, ?, ?, ?, ?)");
    $stmt_student->bind_param("sssss", $adno, $name, $date, $address, $contact);

    // Execute the student insertion
    if ($stmt_student->execute()) {
        echo "New record created successfully for student<br>";
    } else {
        echo "Error: " . $stmt_student->error . "<br>";
    }

    // Close the student statement
    $stmt_student->close();

  /*  // Prepare and bind the SQL statement for payment insertion
    $stmt_payment = $conn->prepare("INSERT INTO payment (ad_no, month) VALUES (?, ?)");
    $stmt_payment->bind_param("ss", $adno, $month);

    // Execute the payment insertion
    if ($stmt_payment->execute()) {
        echo "New record created successfully for payment<br>";
    } else {
        echo "Error: " . $stmt_payment->error . "<br>";
    }

    // Close the payment statement
    $stmt_payment->close();*/
}

// Close the database connection
$conn->close();
?>




    

</body>
</html>
