<?php
function homeFunction($param) {
    return $param === 'expected_value' ? 'expected output' : 'unexpected output';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="style.css">
    <title>Seven Joy PreSchool</title>
    <link rel="icon" href="./photos/Seven Joy Logo.png" type="image/png">
</head>

<body>

    <div class="header">
        <div class="headertext">
            <h1>Welcome to Preschool</h1>
        </div>
</div>
    
    <div class="nav">
        <a href="admission.php">Student Informations</a>
        <a href="teachers.php">Teachers Informations</a>
        <a href="checkpayment.php">Payment</a>
        <a href="booklist.php">Book List</a>
        <a href="uniforms.php">Uniforms</a>
    </div>
    
    <div class="home-img">
        <img src="./photos/Seven Joy Logo.png" alt="Seven Joy Logo">
    </div>
    
    <div class="school-name">Seven Joy Pre School</div>

    <div class="footer">
        <p>&copy; 2024 Seven Joy Preschool. All rights reserved.</p>
    </div>

</body>
</html>
