<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="style1.css">
    <title>Seven Joy PreSchool</title>
    <link rel="icon" href="./photos/Seven Joy Logo.png" type="image/png">
</head>

<body>

    <div class="header">
        <div class="headertext">
        <div class="school-name">Seven Joy Pre School</div>

        </div>
</div>
    
    <div class="nav">
        <a href="home.php">Home</a>
        <a href="checkpayment.php">Check Payment</a>
        <a href="printreceipt.html">Print Receipt</a>
        
    </div>
    
    
    <div class="title-container">
    <h2 class="title">New Payment</h2>
</div>
    
<form action="#" method="GET">
      <label for="ad_no">Admission number:</label>
      <input type="text" id="ad_no" name="ad_no" required>

      <label for="month">Month:</label>
            <select id="month" name="month" required>
                <option value="">Select The Paying Month</option>
                <option value=" January">January</option>
                <option value="February">February</option>
                <option value="March">March</option>
                <option value="April">April</option>
                <option value="May">May</option>
                <option value="June">June</option>
                <option value=" July">July</option>
                <option value="August">August</option>
                <option value="September">September</option>
                <option value="October">October</option>
                <option value="November">November</option>
                <option value="December">December</option>
            </select>  

      <input type="submit" value="Submit"></div></div>
    

      <?php
            ini_set('display_errors', 'off');
include 'dbconnection.php';

 
$rno = $_GET['ad_no'];
$ost = $_GET['month'];



if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
else{

	

    $sql = "DELETE FROM payment WHERE ad_no=$rno";
	

if ($conn->query($sql) === TRUE) {
  
} else {
  echo "Error deleting record: " . $conn->error;
}

	$sql = "insert into payment   
    values ('".$rno."','".$ost."')";

	if ($conn->query($sql) === TRUE) {

	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	$conn->close();
}


?>

</body>
</html>
