<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="style1.css">
    <title>Seven Joy PreSchool</title>
    <link rel="icon" href="./photos/Seven Joy Logo.png" type="image/png">
</head>

<body>

    <div class="header">
        <div class="headertext">
        <div class="school-name">Seven Joy Pre School</div>

        </div>
</div>
    
    <div class="nav">
        <a href="home.php">Home</a>
        <a href="admission.php">Admission</a>
        
    </div>
    
    <div class="title-container">
    <h2 class="title">Student Details</h2>
</div>
    

<form action="#" method="GET">
      <label for="ad_no">Admission number:</label>
      <input type="text" id="ad_no" name="ad_no" required>
    
      <input type="submit" value="Submit"></div></div>

      <?php
       ini_set('display_errors', 'off');
include 'dbconnection.php';

$id = $_GET['ad_no'];

if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
else{
	
	echo "";
	$sql = "SELECT * FROM  student where ad_no='$id' ";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
        echo "<br><br><br><strong>Admission Number :</strong> ". $row["ad_no"]. "<br>";
        echo "<br><strong>Student Name :</strong> ". $row["name"]. "<br>";
        echo "<br><strong>Birthday :</strong> ". $row["birthday"]. "<br>";
        echo "<br><strong>Address:</strong> ". $row["address"]. "<br>";
        echo "<br><strong>Contact number:</strong> ". $row["contact"]. "<br>";
    }

    

} else {
    echo "";
}


$conn->close();
	
}


?>

</body>
</html>
