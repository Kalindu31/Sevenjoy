<?php
function booklistFunction($param) {
    return $param === 'expected_value' ? 'expected output' : 'unexpected output';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="style1.css">
    <title>Seven Joy PreSchool</title>
    <link rel="icon" href="./photos/Seven Joy Logo.png" type="image/png">
</head>

<body>

    <div class="header">
        <div class="headertext">
        <div class="school-name">Seven Joy Pre School</div>

        </div>
</div>
    
    <div class="nav">
        <a href="home.php">Home</a>
        
    </div>
    
    
    <div class="title-container">
    <h2 class="title">Book List</h2>
</div>
    


    <center><img id="imageToPrint" src="photos/booklist.png" alt="Book List Image">
    <br><br>
    <div class="button-container">
    <div class="button" onclick="printImage()" a href="home.php">Print Image</div></div></center>
    <script>
        function printImage() {
            var image = document.getElementById("imageToPrint");
            var imageSrc = image.src;

            // Create a new window with the image to print
            var printWindow = window.open("", "_blank");
            printWindow.document.write("<img src='" + imageSrc + "' style='max-width:100%;'>");

            // Print the contents of the new window
            printWindow.document.close(); // Close the document opened with document.write
            printWindow.print();
        }
    </script>


</body>
</html>
