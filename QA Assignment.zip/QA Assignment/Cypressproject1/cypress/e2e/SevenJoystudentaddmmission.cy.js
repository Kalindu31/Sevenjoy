it('Seven Joy',() => {
    cy.visit('http://localhost/Seven joy 01/Seven joy 01')
    cy.contains('Student Information').click()
    cy.get('#ad_no').type('01')
    cy.get('#student_name').type('Kalindu Harshana')
    cy.get('#date').type('2001-12-31')
    cy.get('#address').type('57,egodauyana,moratuwa')
    cy.get('#contact').type('0776033898')
    cy.get('#month').select('January')
    cy.get('[type="submit"]').click();

    })
    