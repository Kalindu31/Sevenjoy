it('Seven Joy',() => {
    cy.visit('http://localhost/Seven joy 01/Seven joy 01')
    cy.get('[href="teachers.php"]').click()
    cy.get('#ad_no').type('04')
    cy.get('#t_name').type('Thushari Indika')
    cy.get('#date').type('2001-10-03')
    cy.get('#address').type('no82,panadura')
    cy.get('#contact').type('0772102586')
    cy.get('[type="submit"]').click()


})