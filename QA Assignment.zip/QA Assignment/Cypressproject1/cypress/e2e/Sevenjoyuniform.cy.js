it('Seven Joy',() => {
    cy.visit('http://localhost/Seven joy 01/Seven joy 01')
    cy.get('[href="uniforms.php"]').click()
    cy.get('#item').select('shorts')
    cy.get('#size').select('S')
    cy.get('[method="GET"] > input').click()
    cy.get('#count').type('2')
    cy.get('[method="post"] > [type="submit"]').click()

  })
